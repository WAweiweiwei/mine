"""
自定义的分页组件
使用方法：
1、视图函数
注意还需要修改路径

def pretty_list(request):
    # 导包
    from app01.utils.pagination import Pagination

    # 1、根据自己的情况筛选数据
    pretty = PrettyNum.objects.filter(**dict).order_by('-leval')
    # 2、实例化分页的类
    page_object = Pagination(request,pretty,path='/xx/xx/')
    # page_pretty = page_object.page_pretty
    # page_string = page_object.html()

    context = {
         'queryse': page_object.page_pretty,,#分完页的数据
         'page_string': page_string #页码
    }

    return render(request, 'pretty_list.html',context)

2、在html中
 {% for item in pretty %}
    {{obj.xx}}
 {% endfor %}


  <ul class="pagination">
    {{page_string}}
  </ul>
"""
from django.utils.safestring import mark_safe

class Pagination(object):
    def __init__(self,request,pretty,page_size=10,page_param="page",plus=5,path=''):
        """

        :param request: 请求的对象
        :param pretty: 查询的符合条件的数据
        :param page_size:每页显示数据条数
        :param page_param:在url中传递的获取分页的参数，例如：/pretty/list/?page=2
        :param plus:显示当前页的前或后几页（页码）
        """
        import copy
        from django.http.request import QueryDict

        query_dict = copy.deepcopy(request.GET)
        query_dict.__mutable = True
        self.query_dict = query_dict


        page = request.GET.get(page_param, "1")
        if page.isdecimal():
            page = int(page)
        else:
            page = 1
        self.page = page
        self.path = path
        self.page_size = page_size
        self.start = (page - 1) * page_size
        self.end = page * page_size
        self.page_pretty = pretty[self.start:self.end]

        total_count = pretty.count()

        # 页数
        total_page_count, div = divmod(total_count, page_size)
        if div:
            total_page_count += 1
        self.total_page_count = total_page_count
        self.plus = plus
        self.page_param = page_param

    def html(self):
        if self.total_page_count <= 2 * self.plus + 1:
            # 数据库中数据比较少，都没有达到11页
            print('数据库中数据比较少，都没有达到11页')
            start_page = 1
            end_page = self.total_page_count

        else:
            # 数据库页数大于11
            # 当前页<5（小极值）
            if self.page <= self.plus:
                start_page = 1
                end_page = 2 * self.plus + 1
            else:
                # 当前页>总页数-5（大极值）
                if (self.page + self.plus) > self.total_page_count:
                    start_page = self.total_page_count - 2 * self.plus
                    end_page = self.total_page_count
                else:
                    start_page = self.page - self.plus
                    end_page = self.page + self.plus

        page_str_list = []
        self.query_dict.setlist(self.page_param, [1])
        print(self.query_dict.urlencode())

        # 上一页
        prev = '<li class="active"><a href="{}?{}">首页</a></li>'.format(self.path,self.query_dict.urlencode())
        page_str_list.append(prev)
        if self.page > 1:
            self.query_dict.setlist(self.page_param, [self.page - 1])
            prev = '<li class="active"><a href="{}?{}"><<</a></li>'.format(self.path,self.query_dict.urlencode())
        else:
            self.query_dict.setlist(self.page_param, [1])
            prev = '<li class="active"><a href="{}?{}"><<</a></li>'.format(self.path,self.query_dict.urlencode())
        page_str_list.append(prev)

        for i in range(start_page, end_page + 1):
            self.query_dict.setlist(self.page_param, [i])
            # 给当前页的页数加样式
            if i == self.page:
                # self.query_dict.setlist(self.page_param, [1])
                ele = '<li class="active"><a href="{}?{}">{}</a></li>'.format(self.path,self.query_dict.urlencode(), i)
            else:
                # self.query_dict.setlist(self.page_param, [1])
                ele = '<li><a href="{}?{}">{}</a></li>'.format(self.path,self.query_dict.urlencode(), i)
            page_str_list.append(ele)

        # 下一页
        if self.page < self.total_page_count:
            self.query_dict.setlist(self.page_param, [self.page + 1])
            prev = '<li class="active"><a href="{}?{}">>></a></li>'.format(self.path,self.query_dict.urlencode())
        else:
            self.query_dict.setlist(self.page_param, [self.total_page_count])
            prev = '<li class="active"><a href="{}?{}">>></a></li>'.format(self.path,self.query_dict.urlencode())
        page_str_list.append(prev)

        self.query_dict.setlist(self.page_param, [self.total_page_count])
        prev = '<li class="active"><a href="{}?{}">尾页</a></li>'.format(self.path,self.query_dict.urlencode())
        page_str_list.append(prev)

        page_string = mark_safe(''.join(page_str_list))
        return page_string

        # def html(self):
        #     if self.total_page_count <= 2 * self.plus + 1:
        #         # 数据库中数据比较少，都没有达到11页
        #         print('数据库中数据比较少，都没有达到11页')
        #         start_page = 1
        #         end_page = self.total_page_count
        #
        #     else:
        #         # 数据库页数大于11
        #         # 当前页<5（小极值）
        #         if self.page <= self.plus:
        #             start_page = 1
        #             end_page = 2 * self.plus + 1
        #         else:
        #             # 当前页>总页数-5（大极值）
        #             if (self.page + self.plus) > self.total_page_count:
        #                 start_page = self.total_page_count - 2 * self.plus
        #                 end_page = self.total_page_count
        #             else:
        #                 start_page = self.page - self.plus
        #                 end_page = self.page + self.plus
        #
        #     page_str_list = []
        #     self.query_dict.setlist(self.page_param, [1])
        #     print(self.query_dict.urlencode())
        #
        #     # 上一页
        #     prev = '<li class="active"><a href="/prettynum/list/?{}">首页</a></li>'.format(self.query_dict.urlencode())
        #     page_str_list.append(prev)
        #     if self.page > 1:
        #         self.query_dict.setlist(self.page_param, [self.page - 1])
        #         prev = '<li class="active"><a href="/prettynum/list/?{}"><<</a></li>'.format(
        #             self.query_dict.urlencode())
        #     else:
        #         self.query_dict.setlist(self.page_param, [1])
        #         prev = '<li class="active"><a href="/prettynum/list/?{}"><<</a></li>'.format(
        #             self.query_dict.urlencode())
        #     page_str_list.append(prev)
        #
        #     for i in range(start_page, end_page + 1):
        #         self.query_dict.setlist(self.page_param, [i])
        #         # 给当前页的页数加样式
        #         if i == self.page:
        #             # self.query_dict.setlist(self.page_param, [1])
        #             ele = '<li class="active"><a href="/prettynum/list/?{}">{}</a></li>'.format(
        #                 self.query_dict.urlencode(), i)
        #         else:
        #             # self.query_dict.setlist(self.page_param, [1])
        #             ele = '<li><a href="/prettynum/list/?{}">{}</a></li>'.format(self.query_dict.urlencode(), i)
        #         page_str_list.append(ele)
        #
        #     # 下一页
        #     if self.page < self.total_page_count:
        #         self.query_dict.setlist(self.page_param, [self.page + 1])
        #         prev = '<li class="active"><a href="/prettynum/list/?{}">>></a></li>'.format(
        #             self.query_dict.urlencode())
        #     else:
        #         self.query_dict.setlist(self.page_param, [self.total_page_count])
        #         prev = '<li class="active"><a href="/prettynum/list/?{}">>></a></li>'.format(
        #             self.query_dict.urlencode())
        #     page_str_list.append(prev)
        #
        #     self.query_dict.setlist(self.page_param, [self.total_page_count])
        #     prev = '<li class="active"><a href="/prettynum/list/?{}">尾页</a></li>'.format(self.query_dict.urlencode())
        #     page_str_list.append(prev)
        #
        #     page_string = mark_safe(''.join(page_str_list))
        #     return page_string
#