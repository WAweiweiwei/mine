# -*- coding:utf-8 -*-
'''
__author__ = 'ww'
__mtime__ = 2022/12/10
__project__ = IDRPred
Fix the Problem, Not the Blame.
'''

import logging
import os, time, random
import textwrap
import traceback


from django.core.mail import send_mail, EmailMultiAlternatives
from django.template import loader

from IDRPred.settings import DEBUG, EMAIL_HOST_USER
from .ThreadPool import global_mail_thread_pool
from . import models
import pdfkit
from django.urls import reverse

log = logging.getLogger("IDRPred.mail")
if DEBUG:
    RESULT_URL_PRE = "http://127.0.0.1:8000"
else:
    # 需要修改
    RESULT_URL_PRE = "http://structure.bmc.lu.se/PON-Sol2"
AUTHOR_EMAIL = ["1608481511@qq.com", ]
FROM_EMAIL = EMAIL_HOST_USER


def send_result(task_id, ):
    # load email template
    task = models.Task.objects.get(id=task_id)
    to_mail = task.mail
    print('send_result   to_mail',to_mail)
    if to_mail:
        message = loader.render_to_string("email/email.html",
                                          {
                                              "url": f" ({RESULT_URL_PRE}/task/{task_id})",
                                              "task": task,
                                          })
        print(generatePDF(task))
        pdf = generatePDF(task) if task.status != "error" else None
        print('pdf:',pdf)
        log.debug("单独使用邮件线程池，发送邮件")
        print("单独使用邮件线程池，发送邮件")
        # 发给用户
        global_mail_thread_pool.add_task(f"mail_{task_id}", _send_mail, task, message, to_mail,
                                         "Result of IDRPred - Task{}".format(task.id), 30, pdf=pdf)
        print('发给用户')
        # 发给管理员
        # 没有 pdf
        global_mail_thread_pool.add_task(f"mail_{task_id}_au", _send_mail, task, message, AUTHOR_EMAIL,
                                         "Result of IDRPred - Task{} -> {}".format(task.id, to_mail), 60, )
        print('no pdf')




def _send_mail(task, msg, to_mail, subject="Result of IDRPred", sleep_time=10, pdf=None):
    if not isinstance(to_mail, (list, tuple)):
        to_mail = [to_mail, ]
    log.info("发送邮件: %s\n%s\n%s", to_mail, subject, textwrap.shorten(msg, 100))
    log.info("发送邮件: %s\n%s\n%s", to_mail, subject, textwrap.shorten(msg, 100))
    try:
        mail = EmailMultiAlternatives(subject, from_email=FROM_EMAIL, to=to_mail)
        mail.attach_alternative(msg, "text/html")
        if pdf:
            mail.attach(subject + ".pdf", pdf)
        mail.content_subtype = "plain"
        res = mail.send()
        if task.email_res:
            task.email_res += str(res)
        else:
            task.email_res = str(res)
        task.save()
        log.info("发送邮件结果: %s", res)
        print("发送邮件结果: %s", res)
        sleep_time = random.randint(max(0, sleep_time - 5), sleep_time + 5)
        log.info("休眠%s秒", sleep_time)
        time.sleep(sleep_time)
    except Exception:
        msg = traceback.format_exc()
        log.warning("发送邮件失败: %s", traceback.format_exc())
        print("发送邮件失败: %s", traceback.format_exc())
        if task.email_res:
            task.email_res += str(msg)
        else:
            task.email_res = str(msg)
        task.save()


def generatePDF(task):
    log.info("生成 pdf")
    print("生成 pdf","http://127.0.0.1:8000" + "/task/{}".format(task.id) + "?type=email")
    # 生成 pdf 并返回
    pdf = pdfkit.from_url(
        "http://127.0.0.1:8000" + "/task/{}".format(task.id) + "?type=email",
        False)
    # pdf = pdfkit.from_url(
    #     "http://127.0.0.1:8000" + "/task/{}/".format(task.id) + "?type=email",
    #     # return redirect("/task/{}/".format(task.id))
    #     # "http://127.0.0.1:80" + reverse("ponsol2:task-detail", args=(task.id,)) + "?type=email",
    #     False)
    log.info("生成 pdf 完成！")
    print("生成 pdf完成")
    return pdf


from IDRPred import settings
from django.shortcuts import render,HttpResponse,redirect
def send_email():
    subject = 'C语言中文网链接'  # 主题
    from_email = settings.EMAIL_FROM  # 发件人，在settings.py中已经配置
    to_email = '1608481511@qq.com'  # 邮件接收者列表
    # 发送的消息
    message = 'c语言中文网欢迎你点击登录 http://c.biancheng.net/'  # 发送普通的消息使用的时候message
    # meg_html = '<a href="http://www.baidu.com">点击跳转</a>'  # 发送的是一个html消息 需要指定
    send_mail(subject, message, from_email, [to_email])
    return HttpResponse('OK,邮件已经发送成功!')

from django.core.mail import send_mass_mail
message1 = ('Subject here', 'Here is the message', 'from@example.com', ['first@example.com', 'other@example.com'])
message2 = ('Another Subject', 'Here is another message', 'from@example.com', ['second@test.com'])
#接收元组作为参数
# send_email() #fail_silentl运行异常的时候是否报错，默认为True不报错