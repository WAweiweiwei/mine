"""IDRPred URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from app01 import views
from django.views.generic import TemplateView
from django.views import static
from django.conf import settings
from django.conf.urls import url


urlpatterns = [
# #     增加处理识别静态资源5
#     url(r'^static/(?P<path>.*)', static.serve, {'document_root': settings.STATIC_ROOT}, name='static'),
# hide
    path("task/", views.task_list, name="task-list"),
    path("task/running/", views.get_running_tasks, name="task-running"),
    path("task/email/template", TemplateView.as_view(template_name="email/email.html")),
    path("task/email/template/task_detail", TemplateView.as_view(template_name="email/task_detail.html")),
    path("task/email/", views.get_running_mail, name="mail-running"),
    path("zlj/download/db/", views.download_db, name="download-db"),
    path("zlj/download/csv/", views.download_csv, name="download-db"),

    # # HOME
    path("index/", views.index),
    # Variation prediction
    path("input/index/", TemplateView.as_view(template_name="predict_index.html"), name="input"),  # 输入数据
    path("input/sequence/", views.input_seq),  # 通过序列预测
    path("input/id/", views.input_protein_id, name="seq-id"),  # 通过id预测
    path("input/protein/", views.input_protein, name="protein-predict"),  # 通过id预测
    path("predict/seq/", views.predict_seq, name="predict-seq"),  # 预测
    path("predict/ids/", views.predict_ids, name="predict-ids"),
    path("predict/protein/", views.predict_protein, name="predict-protein"),

    # result
    path("task/<int:task_id>/", views.task_detail, name="task-detail"),
    path("record/<int:record_id>", views.record_detail, name="record-detail"),
    path("task/protein/<int:record_id>", views.protein_detail, name="protein_detail"),

    # about
    path("about/", views.get_about, name="about"),
    path("disclaimer/",views.get_disclaimer, name="disclaimer"),
    path("download/",views.get_download, name="download"),
    # predict
    path("predict/seq/", views.predict_seq, name="predict-seq"),  # 预测


    # download
    path("download/idr_dataset/train/", views.download_dataset_idr_train, name="download-dataset-idr_train"),
    path("download/idr_dataset/blind/", views.download_dataset_idr_blind, name="download-dataset-idr_blind"),
    path("download/idr_dataset/pon-all/", views.download_dataset_idr_ponall, name="download-dataset-idr_ponall"),
    path("download/idr_dataset/clinvar/", views.download_dataset_idr_clinvar, name="download-dataset-idr_clinvar"),
    # path("download/ponsol_dataset", views.download_dataset_ponsol, name="download-dataset-ponsol"),
    path("download/example/input_fasta_seq", views.download_example_input_fasta_seq,
         name="download-example-input-fasta-seq"),
    path("download/example/input_fasta_aa", views.download_example_input_aas,
         name="download-example-input-fasta-aa"),
    path("download/example/input_fasta_id", views.download_example_input_aa_and_id,
         name="download-example-input-fasta-id"),

    # account
    path("accounts/", include("django.contrib.auth.urls")),


]
