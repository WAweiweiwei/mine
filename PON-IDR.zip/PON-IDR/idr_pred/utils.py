#!/usr/bin/env python
# coding: utf-8


# 常规类
# 基本的数据处理库
import pandas as pd
import numpy as np
import os

# 导入数据
# matplotlib 设置
pd.options.display.max_rows = 10  # 表格最大行数为10

# 机器学习相关库
from sklearn.model_selection import cross_val_score, cross_validate, StratifiedKFold
from sklearn.metrics import confusion_matrix, accuracy_score, multilabel_confusion_matrix

skf = StratifiedKFold(n_splits=10, shuffle=True, random_state=0)  # 10 层交叉验证（随机打乱）（训练/测试集数据分布与原数据分布一致）


# 计算指标


# 评价指标

def tolerance_metrics(y_true, y_pre):
    """
    计算 tolerance 需要的六个指标
    :param y_true: 标签的正确值
    :param y_pre: 标签的预测值
    :return : (六个指标) -> (DateFrame)
    """
    #     y_true, y_pre = y_test1, p_test1
    label = pd.DataFrame({'true': y_true, 'pre': y_pre})

    # 计算每一类的 TP、FN、FP、TN
    unique_state = label.true.unique()  # 寻找到唯一的标签
    targets = {}  # 保存结果
    state_map = {1: 'p', 0: 'n', '0': 'p', '0': 'n'}
    tp = fp = tn = fn = 0
    for i, (t, p) in label.iterrows():
        # i, t, p -> 索引，真实值，预测值
        if t == 0 and p == 0:
            tn += 1
        if t == 0 and p == 1:
            fp += 1
        if t == 1 and p == 1:
            tp += 1
        if t == 1 and p == 0:
            fn += 1

    allp = tp + fn
    alln = fp + tn


    # 六个计算指标
    N = tp + tn + fp + fn
    # ppv
    ppv = tp / (tp + fp)
    # npv
    npv = tn / (tn + fn)
    # sensitivity -> TPR
    sen = tp / (tp + fn)
    # spciticity -> TNR
    spe = tn / (tn + fp)
    # acc
    acc = (tp + tn) / N
    # MCC
    mcc = (tp*tn-fp*fn) /(((tp+fp) * (tp+fn) * (tn+fp) * (tn+fn))**0.5)
    # 构造成 pandas
    columns = ['tp', 'tn', 'fp', 'fn', 'ppv', 'npv', 'tpr', 'tnr', 'acc', 'mcc']
    res2 = pd.DataFrame(
        [
            [tp, tn, fp, fn, ppv, npv, sen, spe, acc, mcc]
        ],
        columns=columns,
    )
    # 其他数据（保留，暂时不会用到）


    return res2