import joblib
import math
import copy
import pandas as pd
import numpy as np
import lightgbm as lgb
import logging
import os
import shutil
# from idr_pred import feature_extraction
# from . import , config
from idr_pred import config,logconfig,feature_extraction
from sklearn.ensemble import GradientBoostingClassifier
# import logging
logger = logging.getLogger(__name__)

# 根据cv训练集计算所有的LR值
def calculate_LR(df1, df2):
    """
    df1:cv training set
    df2:cv test set
    """
    # log ((2+c)/(1+c)) + log ((2+c)/ (1+c)), {c==1}

    # 有害和中性注释的字典
    p = {}
    n = {}
    # print('calculate_LR')
    for index, row in df1.iterrows():
        # print(row['uniprot'],row['GO'])
        if (pd.isna(row['GO'])):
            continue
        for i in row['GO'].split(';'):
            if i not in p.keys():
                p[i] = 1
                n[i] = 1
            if (row['ClinSigSimple'] == 1):
                p[i] += 1
            else:
                n[i] += 1
    l = copy.deepcopy(p)
    for i in l.keys():
        l[i] = math.log(p[i] / n[i])
    l

    # 求和计算每个蛋白的lr
    def LR_add(x):
        sum = 0
        if (pd.isna(x)):
            return sum
        for i in x.split(','):
            if i in l:
                sum = sum + l[i]
        return sum

    df1['LR_score'] = df1['GO'].apply(lambda x: LR_add(x))
    df2['LR_score'] = df2['GO'].apply(lambda x: LR_add(x))
    df1 = df1.drop(columns=['GO'])
    df2 = df2.drop(columns=['GO'])
    return df1, df2

# 根据cv训练集计算所有的LR值
def calculate_PA(df1, df2):
    """
    df1:cv training set
    df2:cv test set
    """
    # log ((2+c)/(1+c)) + log ((2+c)/ (1+c)), {c==1}

    # 有害和中性注释的字典
    p = {}
    n = {}
    # print('calculate_PA')
    for index, row in df1.iterrows():
        # print(row['uniprot'], row['site'])
        if (pd.isna(row['site'])):
            continue
        for i in row['site'].split(';'):
            if i != '':
                if i not in p.keys():
                    p[i] = 1
                    n[i] = 1
                if (row['ClinSigSimple'] == 1):
                    p[i] += 1
                else:
                    n[i] += 1

    s = copy.deepcopy(p)
    for i in s.keys():
        s[i] = math.log(p[i] / n[i])
    s

    # 求和计算每个蛋白的pa
    def PA_add(x):
        sum = 0
        if (pd.isna(x)):
            return sum
        for i in x.split(','):
            if i != '' and i in s:
                sum = sum + s[i]
        return sum

    df1['PA_score'] = df1['site'].apply(lambda x: PA_add(x))
    df2['PA_score'] = df2['site'].apply(lambda x: PA_add(x))
    df1 = df1.drop(columns=['site'])
    df2 = df2.drop(columns=['site'])
    return df1, df2


class IDRPred:
    def __init__(self):
        """
        model
        self.Estimator: 使用的训练器模型
        self.kwargs: 模型参数
        model_path_rf = os.path.join(project_path, "./data/forest_3.pkl")
        model_path_gbm = os.path.join(project_path, "./data/Gbdt_3.pkl")
        model_path_xgb = os.path.join(project_path, "./data/Xgbc_3.pkl")
        model_path_tree = os.path.join(project_path, "./data/tree_3.pkl")
        model_path_gbdt = os.path.join(project_path, "./data/Gbdt_3.pkl")
                """
        self.model_path_rf = config.model_path_rf
        self.model_path_gbm = config.model_path_gbm
        self.model_path_xgb = config.model_path_xgb
        self.model_path_tree = config.model_path_tree
        self.model_path_gbdt = config.model_path_gbdt
        print('模型地址:',self.model_path_xgb,self.model_path_gbm,self.model_path_gbdt,self.model_path_rf,self.model_path_tree)
        self.model_rf = joblib.load(self.model_path_rf)
        self.model_gbdt = joblib.load(self.model_path_gbdt)
        self.model_xgb = joblib.load(self.model_path_xgb)
        self.model_tree= joblib.load(self.model_path_tree)
        self.model_gbm = joblib.load(self.model_path_gbm)


    def check_X(self, X):
        # 检查类型
        print('开始检查，已经进入check')
        if not isinstance(X, pd.DataFrame):
            raise RuntimeError("The input is not the object of pandas.DataFrame")
        # 检查特征
        # all_features = set(self.model.to_list() )
        # input_data_features = set(X.columns.to_list())
        # reduce_features = all_features - input_data_features
        # if len(reduce_features) > 0:
        #     raise RuntimeError("缺少特征:%s" % reduce_features)
        return True

    def predict(self, uid, seq, aa):
        """
        预测
        :param seq: 氨基酸序列，不包含名称
        :param aa: 变异，索引从1开始，e.g. A1B
        :return: 预测结果
        """
        print('开始预测',uid)
        # uid,seq,mut
        all_features = feature_extraction.get_all_features(uid,seq, aa)
        # train = pd.read_csv(r'idr_pred/data/train_motify_1.csv')
        current_path = str(os.path.abspath(__file__)).replace('model.py',r'data\train_motify_1.csv')
        print('目录',current_path)
        train = pd.read_csv(current_path)
        # train = pd.read_csv(r'C:\Users\weiawei\Desktop\mine\PON-IDR\idr_pred\data\train_motify_1.csv')
        # train = pd.read_csv('idr_pred/data/train_motify.csv')C:\Users\weiawei\Desktop\mine\PON-IDR\idr_pred\model.py

        test =  all_features
        # print(test)
        df1_LR , df2_LR = calculate_LR(train,test)
        df1_PA , df2_PA = calculate_PA(train,test)
        # print('LR_score,PA_score',df1_LR,df1_PA)
        # print(all_features)
        # print(type(all_features))
        # print(len(all_features))
        # features = pd.concat(
        #     {'HUTJ700102':all_features['HUTJ700102'], 'ISOY800105':all_features['ISOY800105'], 'NAKH920107':all_features['NAKH920107'], 'PRAM900102':all_features['PRAM900102'], 'ZHAC000103':all_features['ZHAC000103'], 'sift4g':all_features['sift4g'], 'elm_mod':all_features['elm_mod'], 'EN':all_features['EN'], 'LR_score':all_features['LR'], 'PA_score':all_features['PA']}, axis=1)
        features = pd.concat({'pos': all_features['pos'], 'CIDH920101': all_features['CIDH920101'],
                                           'FASG760105': all_features['FASG760105'],
                                           'GEIM800103': all_features['GEIM800103'],
                                           'JUNJ780101': all_features['JUNJ780101'],
                                           'KARP850103': all_features['KARP850103'],
                                           'NAKH920103': all_features['NAKH920103'],
                                           'OOBM770104': all_features['OOBM770104'],
                                           'RACS820101': all_features['RACS820101'],
                                           'RACS820102': all_features['RACS820102'],
                                           'RACS820106': all_features['RACS820106'],
                                           'SNEP660102': all_features['SNEP660102'],
                                           'TANS770102': all_features['TANS770102'],
                                           'TANS770110': all_features['TANS770110'],
                                           'VELV850101': all_features['VELV850101'],
                                           'AURR980107': all_features['AURR980107'],
                                           'WILM950101': all_features['WILM950101'],
                                           'GEOR030105': all_features['GEOR030105'],
                                           'MIYS930101': all_features['MIYS930101'],
                                           'VENM980101': all_features['VENM980101'],
                                           'BONM030106': all_features['BONM030106'],
                                           'SIMK990104': all_features['SIMK990104'],
                                           'ZHAC000102': all_features['ZHAC000102'], 'num_T': all_features['num_T'],
                                           'num_Polar': all_features['num_Polar'],
                                           'num_Charged': all_features['num_Charged'],
                                           'num_Neg': all_features['num_Neg'], 'sift4g': all_features['sift4g'],
                                           'idr': all_features['idr'], 'elm_deg': all_features['elm_deg'],
                                           'elm_lig': all_features['elm_lig'], 'elm_mod': all_features['elm_mod'],
                                           'VR': all_features['VR'], 'GN': all_features['GN'], 'IE': all_features['IE'],
                                           'KE': all_features['KE'], 'VE': all_features['VE'], 'RG': all_features['RG'],
                                           'GI': all_features['GI'], 'EL': all_features['EL'], 'SL': all_features['SL'],
                                           'VL': all_features['VL'], 'AP': all_features['AP'], 'QP': all_features['QP'],
                                           'SP': all_features['SP'], 'TP': all_features['TP'], 'SS': all_features['SS'],
                                           'SE_mut': all_features['SE'], 'LR_score': all_features['LR_score'],
                                           'PA_score': all_features['PA_score']}, axis=1)
        # print(features)
        if aa[0][0] == aa[0][-1]:
            # print(aa)
            return 0
        pred = self._predict(features)
        # print(pred)
        # pred = self._predict(all_features)
        return pred


    def _predict(self,X):
    # def _predict(self,df2, kind, ip):
        # # 检查 X
        print('开始预测')
        self.check_X(X)
        print('cheack_X完毕')

        pre_all = []
        pred_rf = self.model_rf.predict(X)

        pre_all.append(pred_rf)
        pred_xgb = self.model_xgb.predict(X)

        pre_all.append(pred_xgb)
        pred_gbm = self.model_gbm.predict(X)

        pre_all.append(pred_gbm)
        pred_gbdt = self.model_gbdt.predict(X)

        pre_all.append(pred_gbdt)
        pred_tree = self.model_tree.predict(X)

        pre_all.append(pred_tree)
        print('子模型预测完毕')

        con_blind = 1
        index_blind = 0

        result_blind = []
        while (index_blind < len(pre_all[1])):
            # index = 0
            m_1 = 0
            m_0 = 0
            for i in pre_all:
                # m_1 = 0
                # m_0 = 0
                # print(i)
                # print('======',a[i])
                # for j in range(len(i)):
                # print(j)
                if index_blind <= len(i):
                    print('i[index]', i[index_blind])
                    if i[index_blind] == 1:
                        m_1 += 1
                    if i[index_blind] == 0:
                        m_0 += 1
                    con_blind += 1
            print('0:', m_0, '1:', m_1)
            print('====', con_blind, index_blind)

            if m_1 > m_0:
                result_blind.append(1)

            elif m_1 < m_0:
                result_blind.append(0)
            print('result_blind:', len(result_blind), result_blind)

            return result_blind


# if __name__ == '__main__':
#     test = pd.read_csv(r'C:\Users\weiawei\Desktop\mine\PON-IDR_原\idr_pred\all_features_each_tp53_set.csv')
#     train = pd.read_csv(r'C:\Users\weiawei\Desktop\mine\PON-IDR\idr_pred\data\train_motify_1.csv')
#     # 读取CSV文件
#
#
#     # # 添加新列，所有值都为'aa'
#     # train['uniprot'] = 'P04637'
#     #
#     # # 将DataFrame写回CSV文件
#     # train.to_csv(r'C:\Users\weiawei\Desktop\mine\PON-IDR_原\idr_pred\all_features_each_tp53_set.csv', index=False)
#
#     # test = pd.read_csv(r'E:\pythonProject\untitled\2023.9.16\data\blind_20230916_all.csv')
#     df1_LR, df2_LR = calculate_LR(train, test)
#     df1_PA, df2_PA = calculate_PA(train, test)
#     # df2_PA.to_csv(r'E:\pythonProject\untitled\2023.9.16\data\blind_20230916_all_lr_pa.csv',index=False)
#     df2_PA.to_csv(r'C:\Users\weiawei\Desktop\mine\PON-IDR_原\idr_pred\all_features_each_tp53_set_lr_pa.csv',index=False)