import joblib
import math
import copy
import pandas as pd
import numpy as np
import lightgbm as lgb
import logging
import os
import shutil
# from idr_pred import feature_extraction
# from . import , config
from idr_pred import config,logconfig,feature_extraction
from sklearn.ensemble import GradientBoostingClassifier
# import logging
logger = logging.getLogger(__name__)


# 根据cv训练集计算所有的LR值
def calculate_LR(df1, df2):
    """
    df1:cv training set
    df2:cv test set
    """
    # log ((2+c)/(1+c)) + log ((2+c)/ (1+c)), {c==1}

    # 有害和中性注释的字典
    p = {}
    n = {}
    for index, row in df1.iterrows():
        if (pd.isna(row['GO'])):
            continue
        for i in row['GO'].split(','):
            if i not in p.keys():
                p[i] = 1
                n[i] = 1
            if (row['ClinSigSimple'] == 1):
                p[i] += 1
            else:
                n[i] += 1
    l = copy.deepcopy(p)
    for i in l.keys():
        l[i] = math.log(p[i] / n[i])
    l

    # 求和计算每个蛋白的lr
    def LR_add(x):
        sum = 0
        if (pd.isna(x)):
            return sum
        for i in x.split(','):
            if i in l:
                sum = sum + l[i]
        return sum

    df1['LR_score'] = df1['GO'].apply(lambda x: LR_add(x))
    df2['LR_score'] = df2['GO'].apply(lambda x: LR_add(x))
    df1 = df1.drop(columns=['GO'])
    df2 = df2.drop(columns=['GO'])
    return df1, df2


# 根据cv训练集计算所有的LR值
def calculate_PA(df1, df2):
    """
    df1:cv training set
    df2:cv test set
    """
    # log ((2+c)/(1+c)) + log ((2+c)/ (1+c)), {c==1}

    # 有害和中性注释的字典
    p = {}
    n = {}
    for index, row in df1.iterrows():
        if (pd.isna(row['site'])):
            continue
        for i in row['site'].split(','):
            if i != '':
                if i not in p.keys():
                    p[i] = 1
                    n[i] = 1
                if (row['ClinSigSimple'] == 1):
                    p[i] += 1
                else:
                    n[i] += 1

    s = copy.deepcopy(p)
    for i in s.keys():
        s[i] = math.log(p[i] / n[i])
    s

    # 求和计算每个蛋白的pa
    def PA_add(x):
        sum = 0
        if (pd.isna(x)):
            return sum
        for i in x.split(','):
            if i != '' and i in s:
                sum = sum + s[i]
        return sum

    df1['PA_score'] = df1['site'].apply(lambda x: PA_add(x))
    df2['PA_score'] = df2['site'].apply(lambda x: PA_add(x))
    df1 = df1.drop(columns=['site'])
    df2 = df2.drop(columns=['site'])
    return df1, df2


class IDRPred:
    def __init__(self):
        """
        model
        self.Estimator: 使用的训练器模型
        self.kwargs: 模型参数
        """
        self.model_path = config.model_path
        print('模型地址:',self.model_path)
        self.model = joblib.load(self.model_path)


    def check_X(self, X):
        # 检查类型
        print('开始检查，已经进入check')
        if not isinstance(X, pd.DataFrame):
            raise RuntimeError("The input is not the object of pandas.DataFrame")
        # 检查特征
        # all_features = set(self.model.to_list() )
        # input_data_features = set(X.columns.to_list())
        # reduce_features = all_features - input_data_features
        # if len(reduce_features) > 0:
        #     raise RuntimeError("缺少特征:%s" % reduce_features)
        return True

    def predict(self, uid, seq, aa):
        """
        预测
        :param seq: 氨基酸序列，不包含名称
        :param aa: 变异，索引从1开始，e.g. A1B
        :return: 预测结果
        """
        print('开始预测',uid)
        # uid,seq,mut
        all_features = feature_extraction.get_all_features(uid,seq, aa)
        train = pd.read_csv('idr_pred/data/train.csv')
        test =  all_features
        df1_LR , df2_LR = calculate_LR(train,test)
        df1_PA , df2_PA = calculate_PA(train,test)
        # print('LR_score,PA_score',df1_LR,df1_PA)
        # print(all_features)
        # print(type(all_features))
        # print(len(all_features))
        features = pd.concat(
            {'HUTJ700102':all_features['HUTJ700102'], 'ISOY800105':all_features['ISOY800105'], 'NAKH920107':all_features['NAKH920107'], 'PRAM900102':all_features['PRAM900102'], 'ZHAC000103':all_features['ZHAC000103'], 'sift4g':all_features['sift4g'], 'elm_mod':all_features['elm_mod'], 'EN':all_features['EN'], 'LR_score':all_features['LR'], 'PA_score':all_features['PA']}, axis=1)

        # print(features)
        if aa[0][0] == aa[0][-1]:
            # print(aa)
            return 0
        pred = self._predict(features)
        # print(pred)
        # pred = self._predict(all_features)
        return pred

        # # err_list,df2 = feature_extraction.get_all_features(n, seq, aa, kind)
        # df2 = feature_extraction.get_all_features(n, seq, aa, kind)

        # # err_list = df2[df2['msg'] != '']
        # # print('错误')
        # # print(err_list)
        # # df2 = df2[df2['msg'] == '']
        # # print('特征')
        # # print(df2)
        # df2.to_csv('{}_test.csv'.format(ip), index=None)
        # # err_list['confidence'] = ''
        # # err_list['pred'] = ''
        # # err_list = err_list[['id', 'confidence', 'pred', 'msg']]
        # confidence, pred = self._predict(df2.iloc[:, 2:], kind, ip)
        # confidence = pd.DataFrame(confidence)
        # confidence.rename(columns={0: 'confidence'}, inplace=True)
        # pred = pd.DataFrame(pred)
        # pred.rename(columns={0: 'pred'}, inplace=True)
        # pred = pd.merge(confidence, pred, left_index=True, right_index=True, how='inner')
        # pred = pd.merge(df2, pred, left_index=True, right_index=True, how='inner')
        # pred = pred[['id', 'confidence', 'pred', 'msg']]
        # # pred = pd.concat([err_list, pred], axis=0)
        # pred.set_index(["id"], inplace=True)
        # print('结果')
        # # print(pred)
        # return pred

    def _predict(self,X):
    # def _predict(self,df2, kind, ip):
        # # 检查 X
        print('开始预测')
        self.check_X(X)

        print('cheack_X完毕')
        pred = self.model.predict(X)
        print('预测完毕')
        return pred


