import hashlib
from django.conf import settings
"""
md5加密
"""
def md5(data_string):
    # 加盐，先不用
    # salt = "xxxxx"
    # obj = hashlib.md5(salt.encode('utf-8'))


    obj = hashlib.md5(settings.SECRET_KEY.encode('utf-8'))
    obj.update(data_string.encode('utf-8'))
    return obj.hexdigest()


