# -*- coding:utf-8 -*-
'''
__author__ = 'ww'
__mtime__ = 2022/12/10
__project__ = IDRPred
Fix the Problem, Not the Blame.
'''
