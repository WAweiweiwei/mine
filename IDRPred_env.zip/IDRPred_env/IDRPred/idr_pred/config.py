# -*- coding:utf-8 -*-
'''
__author__ = 'ww'
__mtime__ = 2022/12/10
__project__ = IDRPred
Fix the Problem, Not the Blame.
'''
import os
import pandas as pd

project_path = os.path.dirname(__file__)
aa_index_path = os.path.join(project_path, "./data/aaindexmatrix.txt")
model_path = os.path.join(project_path, "./data/gbdt_10.pkl")
# model_path = os.path.join(project_path, "./data/gbdt_10.pkl")E:\pythonProject\IDRPred\idr_pred\data\gbdt_10.pkl
# model_path_N = os.path.join(project_path, "./data/lightgbm_feature_select_20_N.rfe")
ancestor_path = os.path.join(project_path, "./data/ANCESTOR.csv")
all_path = os.path.join(project_path, "./data/train_20221106.csv")
# all_bootstrap_path = os.path.join(project_path, "./data/Blind_All_Species/All_species/")
blind_path = os.path.join(project_path, "./data/blind_20221106.csv")
test_bootstrap_path = os.path.join(project_path, "./data/bootstrap_re_lgbm/")



