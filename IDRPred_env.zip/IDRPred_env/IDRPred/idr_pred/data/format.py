import pandas as pd
# data = pd.read_csv('1.csv')
with open('1.csv') as f:
    lines = f.readlines()
    for line in lines:
        line1 = line.split(': ')[1].replace(',',';').replace('}','').replace('None','').replace(' \'','\'')
        with open('train_site.csv','a') as m:
            m.writelines(line1)