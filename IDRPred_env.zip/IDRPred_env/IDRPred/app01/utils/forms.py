
from django.core.exceptions import ValidationError
from django import forms


from app01.models import *
from app01.utils.bootstrap import BootStrapModelForm,BootStrapForm
# 加密
from app01.utils.encrypt import md5

class PrettyEditModelForm(BootStrapModelForm):
    # 手机号不可修改
    mobile = forms.CharField(
        disabled=True,
        label='手机号'

    )

    class Meta:
        model = PrettyNum
        fields = ['mobile' ,'price' ,'leval' ,'status']
        # fields = '__all__' #表示所有的字段
        # exclude  = ['leval'] #排除某个字段
    #         样式



    def clean_mobile(self):
        txt_mobile = self.cleaned_data['mobile']
        # 排除自己以外是否与其他重复
        exists = PrettyNum.objects.exclude(id=self.instance.pk).filter(mobile=txt_mobile).exists()
        if exists:
            raise ValidationError('手机号已存在')


        if len(txt_mobile) != 11:
            # 验证不通过
            raise ValidationError('格式错误')
        # 验证通过，返回用户输入的值
        return txt_mobile


class PrettyModelForm(BootStrapModelForm):
    # 验证方式一：
    # mobile = forms.CharField(
    #     label='手机号',
    #     # 正则表达式
    #     validators = [RegexValidator(r'^1\d{10}$','手机号格式错误')],
    #
    # )

    class Meta:
        model = PrettyNum
        # fields = ['id','mobile','price','leval','status']
        fields = '__all__' #表示所有的字段
        # exclude  = ['leval'] #排除某个字段
        # 加样式 但一般不用，用__init__
        # widgets={
        #     'mobile':forms.TextInput(attrs={'class':'form-control'})
        #     # 'password':forms.Password(attrs={'class':'form-control'})
        # }
#         样式


# 验证方式二：
    def clean_mobile(self):
        txt_mobile = self.cleaned_data['mobile']
        exists = PrettyNum.objects.filter(mobile=txt_mobile).exists()
        if exists:
            raise ValidationError('手机号已存在')


        if len(txt_mobile) != 11:
            # 验证不通过
            raise ValidationError('格式错误')
        # 验证通过，返回用户输入的值
        return txt_mobile


class AdminModelForm(BootStrapModelForm):
    # 确认密码
    confirm_password = forms.CharField(
        label = '确认密码',
    # 隐藏密码,输入错误后 依然会保留原来输入的值
        widget = forms.PasswordInput
    )

    class Meta:
        model = Manager
        fields = '__all__'
        widgets = {
            'password' : forms.PasswordInput(render_value=True)
        }

    def clean_confirm_password(self):
        print(self.cleaned_data)
        pwd = self.cleaned_data.get('password')
        # 确认密码时，也需要转换为md5加密格式
        confirm = md5(self.cleaned_data.get('confirm_password'))
        if confirm != pwd:
            raise ValidationError('密码不一致，请重新输入')
        # return 原因：返回什么，此字段以后保存在数据库就是什么
        return confirm

    # md5加密
    def clean_password(self):
        pwd = self.cleaned_data.get('password')
        return md5(pwd)


class AdminEditModelForm(BootStrapModelForm):
    class Meta:
        model = Manager
        fields = ['username']

class AdminEditPwdModelForm(BootStrapModelForm):
    # 确认密码
    confirm_password = forms.CharField(
        label='确认密码',
        # 隐藏密码,输入错误后 依然会保留原来输入的值
        widget=forms.PasswordInput
    )
    class Meta:
        model = Manager
        fields = ['password','confirm_password']
        widgets = {
            'password': forms.PasswordInput(render_value=True)
        }

    def clean_confirm_password(self):
        print(self.cleaned_data)
        pwd = self.cleaned_data.get('password')
        # 确认密码时，也需要转换为md5加密格式
        confirm = md5(self.cleaned_data.get('confirm_password'))
        if confirm != pwd:
            raise ValidationError('密码不一致，请重新输入')
        # return 原因：返回什么，此字段以后保存在数据库就是什么
        return confirm

    # md5加密
    def clean_password(self):
        pwd = self.cleaned_data.get('password')
        md5_pwd = md5(pwd)
        # 去数据库校验，新设置的密码是否和之前的密码一致
        exits = Manager.objects.filter(id=self.instance.pk,password=md5_pwd).exists()
        if exits:
            raise ValidationError('不能与之前的密码相同')
        return md5_pwd

# 用户登录：LoginForm LoginModelForm都可以
class LoginForm(BootStrapForm):
    username = forms.CharField(
        label='用户名',
        widget=forms.TextInput(attrs={'class':'form-control'}),
        required=True#不能为空

    )
    password = forms.CharField(label='密码', widget=forms.PasswordInput(attrs={'class':'form-control'}),required=True)#不能为空

    code = forms.CharField(label='图片验证码', widget=forms.TextInput(attrs={'class':'form-control'}),required=True)#不能为空

    # md5加密
    def clean_password(self):
        pwd = self.cleaned_data.get('password')
        md5_pwd = md5(pwd)
        # 去数据库校验，新设置的密码是否和之前的密码一致
        # exits = Manager.objects.filter(id=self.instance.pk, password=md5_pwd).exists()
        # if exits:
        #     raise ValidationError('不能与之前的密码相同')
        return md5_pwd

class TaskModelForm(BootStrapModelForm):
    class Meta:
        model = Task
        fields = '__all__'
        widgets = {
            'detail': forms.TextInput
        }
        # widgets={
        #     'detail':Tex
        # }

class OrderModelForm(BootStrapModelForm):
    class Meta:
        model = Order
        # fields = '__all__'
        exclude = ['oid','admin']

class UploadModelForm(BootStrapForm):
    # 消除图片的bootstrap样式
    bootstrap_exclude_fileds = ['img']
    name = forms.CharField(label='姓名')
    age= forms.IntegerField(label='年龄')
    img = forms.FileField(label='照片')

class UploadModelForm1(BootStrapModelForm):
    class Meta:
        model = City
        fields  = '__all__'










