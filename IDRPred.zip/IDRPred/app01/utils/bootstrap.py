from django import forms

class BootStrap:
    # 消除的bootstrap样式
    bootstrap_exclude_fileds = []

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        #         循环找到所有的插件，增加了class='foem-control'
        for name, field in self.fields.items():

            if name in self.bootstrap_exclude_fileds:
                continue
            # if name == 'password':
            # continue
            # 优化：判断原来是否有样式，如果有设置，如果没有直接增加字典
            if field.widget.attrs:
                field.widget.attrs['class'] = 'form-control'
                field.widget.attrs['placeholder'] = field.label
            else:
                field.widget.attrs = {
                    'class': 'form-control',
                    'placeholder': field.label
                }

class BootStrapModelForm(BootStrap,forms.ModelForm):
    pass
class BootStrapForm(BootStrap,forms.Form):
    pass